const currentPlayer = document.querySelector(".currentPlayer");
//currentplayer has been taken from the h2 tag in the html file
let selected;
let player = "X";
// next is the combination that makes the player win the game 
let positions = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9],
  [1, 4, 7],
  [2, 5, 8],
  [3, 6, 9],
  [1, 5, 9],
  [3, 5, 7],
];

function init() {
  selected = [];
//the [] tells the screen to start with empty squares
  currentPlayer.innerHTML = `NEXT PLAYER: ${player}`;
//the following query will make the game starts empty, for instance, if you refresh the screen.
  document.querySelectorAll(".game button").forEach((item) => {
    item.innerHTML = "";
    item.addEventListener("click", newMove);
  });
}

init();

function newMove(e) 
{
//the next function will allow the first player to choose a square based on its position as described in the html file (data-i)
  const index = e.target.getAttribute("data-i");
  e.target.innerHTML = player;
  //the removelistener prevents the same player to click twice as the game should allow only one move per player
  e.target.removeEventListener("click", newMove);
  //variable selected will keep the x or o on the screen based on the player
  selected[index] = player;
  //Next is the interval between the players and the === means strict equality, it checks type and value and it makes the game alternate between x and o based on the last move
  setTimeout(() => {
    check();
  }, [100]);

  player = player === "X" ? "O" : "X";
  currentPlayer.innerHTML = `CURRENT PLAYER: ${player}`;
}
   //The following function will map the Xs and Os to determine the one of the player has reached one of the winning positions based on the let position combination above.
function check() {
  let playerLastMove = player === "X" ? "O" : "X";

  const items = selected
    .map((item, i) => [item, i])
    .filter((item) => item[0] === playerLastMove)
    .map((item) => item[1]);

  for (pos of positions) {
    if (pos.every((item) => items.includes(item))) {
      alert("THE PLAYER '" + playerLastMove + "' IS THE WINNER!");
      init();
      return;
    }
  }
    //If item has reached 9 squares and previous condition
  if (selected.filter((item) => item).length === 9) {
    alert("DRAW!");
    init();
    return;
  }
}